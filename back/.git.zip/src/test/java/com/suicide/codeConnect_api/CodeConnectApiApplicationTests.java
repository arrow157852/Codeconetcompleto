package com.suicide.codeConnect_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeConnectApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
