package com.suicide.codeConnect_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeConnectApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeConnectApiApplication.class, args);
	}

}
