package com.suicide.codeConnect_api.repository;

import com.suicide.codeConnect_api.entity.Poste;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PosteRepository extends JpaRepository<Poste,Long> {

    Optional<Poste> findByTitle(String title);
}
