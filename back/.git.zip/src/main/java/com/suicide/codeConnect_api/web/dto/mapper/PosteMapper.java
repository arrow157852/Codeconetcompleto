package com.suicide.codeConnect_api.web.dto.mapper;

import com.suicide.codeConnect_api.entity.Poste;
import com.suicide.codeConnect_api.entity.Usuario;
import com.suicide.codeConnect_api.web.dto.PosteDto;
import com.suicide.codeConnect_api.web.dto.UsuarioCreateDto;
import com.suicide.codeConnect_api.web.dto.UsuarioResponseDto;
import org.modelmapper.ModelMapper;

public class PosteMapper {



    public static Poste toPoste(PosteDto posteDto){
        return new ModelMapper().map(posteDto, Poste.class);
    }


    public static PosteDto toDto(Poste poste){
        return new ModelMapper().map(poste, PosteDto.class);
    }
}
