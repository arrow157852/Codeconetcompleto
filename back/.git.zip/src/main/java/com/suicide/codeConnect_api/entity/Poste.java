package com.suicide.codeConnect_api.entity;


import jakarta.persistence.*;

import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.time.LocalDateTime;


@Slf4j
@Entity
@Table(name = "post")
public class Poste implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "title", nullable = false, unique = false, length = 100)
    private String title;

    @Column(name = "descricao_post", nullable = false, unique = true, length = 100)
    private String descricaoPost;

    @ManyToOne
    @JoinColumn(name = "usuario_fk")
    private Usuario usuarioFk;

    @Column(name = "data_criacao")
    private LocalDateTime dataCriacao = LocalDateTime.now();


}
